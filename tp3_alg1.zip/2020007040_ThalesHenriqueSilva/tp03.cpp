#include <iostream>
#include <vector>
#include <numeric>

using namespace std;

int main()
{
    //input
    int F, W; 
    cin >> F >> W;
    
    //grid: F x W matrix
    vector<vector<long long>> grid;
    grid.resize(F, vector<long long>(W));
    for (int i = 0;i < F;i++) {
        for (int j = 0;j < W;j++) {
            cin >> grid[i][j];
        }
    }

    //row vector with current maximum values 
    vector<long long> row = grid[F - 1];
    
    //matrix storing parent pointers
    vector<vector<int>> parent;
    parent.resize(F, vector<int>(W,0));
    
    //fill last row with values ranging from 0 to F - 1
    iota(parent[F - 1].begin(), parent[F - 1].end(), 0);
    
    //bottom-up DP: start from last row
	//and build the solution "upwards" 
    for (int i = F - 2;i >= 0;i--) {
        vector<long long> aux = grid.at(i);

        for (int j = 0;j < W;j++) {
            if (j == 0) {
				//first position: there are at most two options
                if (W >= 2) {
                    //two values
                    if (row.at(0) >= row.at(1)) {
                        aux.at(j) += row.at(0);
                        parent[i][j] = 0;
                    } else {
                        aux.at(j) += row.at(1);
                        parent[i][j] = 1;
                    }
                } else {
                    //one value only: W = 1
                    aux.at(j) += row.at(0);
                    parent[i][j] = 0;
                }
            } else if (j == W - 1) {
				//last position: there are at most two options
                if (W >= 2) {
                    //two values
                    if (row.at(W - 1) >= row.at(W - 2)) {
                        parent[i][j] = W - 1;
                        aux.at(j) += row.at(W - 1);
                    } else {
                        parent[i][j] = W - 2;
                        aux.at(j) += row.at(W - 2);                        
                    }
                } else {
                    //one value only: W = 1
                    aux.at(j) += row.at(0);
                    parent[i][j] = 0;
                }
            } else {
                //intermediary position: there are three options
                if (row.at(j) >= row.at(j - 1) && row.at(j) >= row.at(j + 1)) {
                    aux.at(j) += row.at(j);
                    parent[i][j] = j;
                } else if (row.at(j - 1) >= row.at(j) && row.at(j - 1) >= row.at(j + 1)) {
                    aux.at(j) += row.at(j - 1);
                    parent[i][j] = j - 1;
                } else {
                    aux.at(j) += row.at(j + 1);
                    parent[i][j] = j + 1;
                }
            }
        }
        
        //update row vector
        row = aux;
    }
    
    //find MAX
    long long MAX = 0;
    int index;
    for (int i = 0;i < W;i++) {
        if (row.at(i) > MAX) {
            MAX = row.at(i);
            index = i;
        }
    }
    
    //print MAX
    cout << MAX << endl;
    
    //print path
    cout << index << " ";
    for (int i = 1;i < F;i++) {
        cout << parent[i - 1][index] << " ";
        index = parent[i - 1][index];
    }
    return 0;
}